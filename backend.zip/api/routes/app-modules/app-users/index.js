/*
 * @Author: Abderrahim El imame 
 * @Date: 2019-05-18 22:52:39 
 * @Last Modified by:   Abderrahim El imame 
 * @Last Modified time: 2019-05-18 22:52:39 
 */

'use strict';

module.exports = {
  usersQueries: require("./lib/users-queries")
};