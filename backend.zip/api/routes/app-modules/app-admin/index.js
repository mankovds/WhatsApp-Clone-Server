/*
 * @Author: Abderrahim El imame 
 * @Date: 2019-05-18 22:51:21 
 * @Last Modified by:   Abderrahim El imame 
 * @Last Modified time: 2019-05-18 22:51:21 
 */

'use strict';

module.exports = {
  adminQueries: require("./lib/admin-queries")
};