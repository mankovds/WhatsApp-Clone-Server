/*
 * @Author: Abderrahim El imame 
 * @Date: 2019-05-18 22:51:44 
 * @Last Modified by:   Abderrahim El imame 
 * @Last Modified time: 2019-05-18 22:51:44 
 */

'use strict';

module.exports = {
  chatQueries: require("./lib/chat-queries")
};
